import {redirect} from "next/navigation";

const RootPage = () => {
    redirect("/products");
}
export default RootPage
